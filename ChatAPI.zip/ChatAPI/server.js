var express = require('express');
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io').listen(server);
var usernames = {};

server.listen(4000);

app.get('/', function(request, response){
    response.sendFile(__dirname + '/chat.html');
});

app.get('/assets/scripts/chatscript.js', function(request, response){
    response.sendFile(__dirname + '/assets/scripts/chatscript.js');
});

app.get('/assets/scripts/jquery-2.2.4.min.js', function(request, response){
    response.sendFile(__dirname + '/assets/scripts/jquery-2.2.4.min.js');
});

app.get('/assets/css/chatstyle.css', function(request, response){
    response.sendFile(__dirname + '/assets/css/chatstyle.css');
});

io.sockets.on('connection', function(socket){
    socket.on('new user', function(data, callback){
        // user already exists
        if (data in usernames) {
            callback(false);
        }
        else {
            callback(true);
            socket.username = data
            usernames[socket.username] = socket;
            io.sockets.emit('usernames', Object.keys(usernames));
        }
    });
    
    socket.on('disconnect', function(data){
        if (! socket.username) return
        delete usernames[socket.username];
        io.sockets.emit('usernames', Object.keys(usernames));
    });
    
    socket.on('send message', function(data){
        io.sockets.emit('new message', {msg: data, username: socket.username});
    });
});