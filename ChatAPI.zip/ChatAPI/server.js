var express = require('express');
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io').listen(server);
var usernames = {};

server.listen(3000);
console.log('server running at http://127.0.0.1:3000/');

app.get('/', function(request, response){
    response.sendFile(__dirname + '/chat.html');
});

app.get('/assets/scripts/chatscript.js', function(request, response){
    response.sendFile(__dirname + '/assets/scripts/chatscript.js');
});

app.get('/assets/scripts/jquery-2.2.4.min.js', function(request, response){
    response.sendFile(__dirname + '/assets/scripts/jquery-2.2.4.min.js');
});

app.get('/assets/css/chatstyle.css', function(request, response){
    response.sendFile(__dirname + '/assets/css/chatstyle.css');
});

io.sockets.on('connection', function(socket){
    socket.on('new user', function(data, callback){
        // user already exists
        if (data in usernames) {
            callback(false);
        }
        else {
            callback(true);
            socket.username = data
            usernames[socket.username] = socket;
            io.sockets.emit('usernames', Object.keys(usernames));
        }
    });
    
    socket.on('disconnect', function(data){
        if (! socket.username) return
        delete usernames[socket.username];
        io.sockets.emit('usernames', Object.keys(usernames));
    });
    
    socket.on('send message', function(data, callback){
        var message = data.trim();
        // if you want to have a private chat with another user
        if (message.substring(0,1) === '@') {
            message = message.substring(1);
            var index = message.indexOf(' ');
            if (index != -1) {
                var chatWith = message.substring(0, index);
                message = message.substring(index + 1);
                if (chatWith in usernames) {
                    usernames[chatWith].emit('private chat', {msg: message, username: socket.username})
                }
                else {
                    callback('Please enter a valid username');
                }
            }
            else {
                callback('Please enter a message for private chat');
            }
        }
        // public chat
        else {        
            io.sockets.emit('new message', {msg: message, username: socket.username});
        }
    });

});